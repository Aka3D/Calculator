﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;



namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        /*
        [TestMethod]
        public void CalculateSaveTest()
        {
            // nuGet entety

            // Arrange : Daten erzeugen

            var cal = new calculate
            {
                Zahl1 = 5,
                Zahl2 = 6,
                Operation = "Multiplication",
                Resultat = 30,
                Rechnung = $"5 * 6 = 30",
                fk_UserId = 1,
            };

            // Act : Methode ausführen

            using (var context = new calculate())
            {
                var cSave = context.Calculate.Add(cSave);
                context.SaveChanges();
            }

            // Assert : Resultat prüfen

            Assert.IsNotNull(cSave);
            Assert.IsTrue
            Assert.AreEqual(cSave.Calcultaion, "1 + 2 = 3");
            Assert.AreEqual(cSave.RefLogin, 1);

        }
        */
    }
}
